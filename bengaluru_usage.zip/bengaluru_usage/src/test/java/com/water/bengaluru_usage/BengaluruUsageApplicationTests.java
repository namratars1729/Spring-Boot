package com.water.bengaluru_usage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BengaluruUsageApplicationTests {

	@Test
	void contextLoads() {
	}

}
