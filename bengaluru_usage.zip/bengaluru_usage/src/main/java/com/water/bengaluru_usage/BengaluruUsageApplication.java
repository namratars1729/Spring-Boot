package com.water.bengaluru_usage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BengaluruUsageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BengaluruUsageApplication.class, args);
		System.out.println("\n --------------- Hello Spring Boot! -------------------\n");
	}

}
